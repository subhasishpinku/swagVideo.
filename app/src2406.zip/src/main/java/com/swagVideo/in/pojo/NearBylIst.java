package com.swagVideo.in.pojo;

public class NearBylIst {
    int bgImage;
    String km,userImage;

    public NearBylIst(int bgImage, String km, String userImage) {
        this.bgImage = bgImage;
        this.km = km;
        this.userImage = userImage;
    }

    public int getBgImage() {
        return bgImage;
    }

    public void setBgImage(int bgImage) {
        this.bgImage = bgImage;
    }

    public String getKm() {
        return km;
    }

    public void setKm(String km) {
        this.km = km;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }
}
