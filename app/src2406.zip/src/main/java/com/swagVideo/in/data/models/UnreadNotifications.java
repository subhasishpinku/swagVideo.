package com.swagVideo.in.data.models;

public class UnreadNotifications {

    public int count;
}
