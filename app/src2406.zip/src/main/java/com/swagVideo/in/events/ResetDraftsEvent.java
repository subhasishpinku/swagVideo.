package com.swagVideo.in.events;

public class ResetDraftsEvent {
}
