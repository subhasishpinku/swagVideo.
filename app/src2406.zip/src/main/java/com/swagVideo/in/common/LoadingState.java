package com.swagVideo.in.common;

public enum LoadingState {

    IDLE,
    ERROR,
    LOADED,
    LOADING,
}
