package com.swagVideo.in.common;

public interface VisibilityAware {

    void setVisibleOrNot(boolean visible);
}
